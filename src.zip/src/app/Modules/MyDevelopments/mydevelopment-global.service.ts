import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MydevelopmentGlobalService {

  myDevelopmentApiUrls = {
    getUserData: 'https://jsonplaceholder.typicode.com/users'
  }

}
