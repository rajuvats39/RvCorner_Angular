import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { MydevelopmentGlobalService } from './mydevelopment-global.service';
import { GetdataResponse } from './models/response/get-get-data.response.model';
import { AppHttpClientService } from '../../Shared/app-http-client.service';

@Injectable({
  providedIn: 'root'
})
export class MydevelopmentService {

  constructor(
    private httpClient: AppHttpClientService,
    private mydevelopmentGlobalService: MydevelopmentGlobalService
  ) { }

  // public postData(request:any): Observable<any> {
  //   return this.httpClient.get<any, any>(this.mydevelopmentGlobalService.myDevelopmentApiUrls.getData, request);
  // }

  public getUserData(): Observable<GetdataResponse> {
    return this.httpClient.get<any, GetdataResponse>(this.mydevelopmentGlobalService.myDevelopmentApiUrls.getUserData);
  }

}
