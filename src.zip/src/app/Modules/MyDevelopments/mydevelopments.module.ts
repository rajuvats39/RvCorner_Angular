import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MydevelopmentsRoutingModule } from './mydevelopments-routing.module';
import { AddEditDataComponent } from './add-edit-data/add-edit-data.component';
import { GetDataComponent } from './getdata/getdata.component';
import { ToasterComponent } from './toaster/toaster.component';
import { FormsModule } from '@angular/forms';
import { MydevelopmentsComponent } from './mydevelopments.component';
import { ValidationModule } from '../../Shared/validation/validation.module';


@NgModule({
  declarations: [
    ToasterComponent,
    GetDataComponent,
    AddEditDataComponent,
    MydevelopmentsComponent
  ],
  imports: [
    CommonModule,
    MydevelopmentsRoutingModule,
    ValidationModule,
    FormsModule
  ]
})
export class MydevelopmentsModule { }
