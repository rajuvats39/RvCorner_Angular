import { Component } from '@angular/core';

@Component({
  selector: 'app-mydevelopments',
  templateUrl: './mydevelopments.component.html',
  styleUrl: './mydevelopments.component.scss'
})
export class MydevelopmentsComponent {

}
