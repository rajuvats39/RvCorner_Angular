import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RoutersRoutingModule } from './routers-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RoutersRoutingModule
  ]
})
export class RoutersModule { }
