import { Component } from '@angular/core';

@Component({
  selector: 'app-routers',
  templateUrl: './routers.component.html',
  styleUrl: './routers.component.scss'
})
export class RoutersComponent {

}
