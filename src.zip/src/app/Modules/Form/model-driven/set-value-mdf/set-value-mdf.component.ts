import { Component } from '@angular/core';

@Component({
  selector: 'app-set-value-mdf',
  templateUrl: './set-value-mdf.component.html',
  styleUrls: ['./set-value-mdf.component.scss']
})
export class SetValueMDFComponent {

}
