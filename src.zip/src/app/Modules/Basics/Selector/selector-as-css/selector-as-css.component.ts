import { Component } from '@angular/core';

@Component({
  selector: '.app-selector-as-css',
  templateUrl: './selector-as-css.component.html',
  styleUrls: ['./selector-as-css.component.scss']
})
export class SelectorAsCSSComponent {

}
