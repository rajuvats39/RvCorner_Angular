import { Component } from '@angular/core';

@Component({
  selector: '[app-selector-as-attribute]',
  templateUrl: './selector-as-attribute.component.html',
  styleUrls: ['./selector-as-attribute.component.scss']
})
export class SelectorAsAttributeComponent {

}
