import { Component } from '@angular/core';

@Component({
  selector: 'app-style-urls-property',
  templateUrl: './style-urls-property.component.html',
  styleUrls: ['./style-urls-property.component.scss']
})
export class StyleUrlsPropertyComponent {

}
