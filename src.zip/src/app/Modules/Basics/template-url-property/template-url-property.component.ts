import { Component } from '@angular/core';

@Component({
  selector: 'app-template-url-property',
  templateUrl: './template-url-property.component.html',
  styleUrls: ['./template-url-property.component.scss']
})
export class TemplateUrlPropertyComponent {

}
