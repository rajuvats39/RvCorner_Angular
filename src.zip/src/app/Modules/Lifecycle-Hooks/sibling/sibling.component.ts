import { Component } from '@angular/core';

@Component({
  selector: 'app-sibling',
  templateUrl: './sibling.component.html',
  styleUrl: './sibling.component.scss'
})
export class SiblingComponent {

}
