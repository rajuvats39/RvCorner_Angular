import { Component } from '@angular/core';

@Component({
  selector: 'app-state-management',
  templateUrl: './state-management.component.html',
  styleUrl: './state-management.component.scss'
})
export class StateManagementComponent {

}
