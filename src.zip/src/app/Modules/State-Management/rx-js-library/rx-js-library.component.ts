import { Component } from '@angular/core';

@Component({
  selector: 'app-rx-js-library',
  templateUrl: './rx-js-library.component.html',
  styleUrl: './rx-js-library.component.scss'
})
export class RxJsLibraryComponent {

}
