import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { InterviewQARoutingModule } from './interview-qa-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    InterviewQARoutingModule
  ]
})
export class InterviewQAModule { }
