import { Component } from '@angular/core';

@Component({
  selector: 'app-advanced-components',
  templateUrl: './advanced-components.component.html',
  styleUrl: './advanced-components.component.scss'
})
export class AdvancedComponentsComponent {

}
