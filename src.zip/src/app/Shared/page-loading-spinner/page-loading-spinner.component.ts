import { Component } from '@angular/core';

@Component({
  selector: 'app-page-loading-spinner',
  templateUrl: './page-loading-spinner.component.html',
  styleUrl: './page-loading-spinner.component.scss'
})
export class PageLoadingSpinnerComponent {

}
