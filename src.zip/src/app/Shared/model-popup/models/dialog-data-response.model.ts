export interface DialogDataResponse {
    isClickOk: boolean;
    isClickCancel: boolean;
    isClickCloseIcon: boolean;
}