interface UpdateRequest {
  name: string;
  id: string;
  email: string;
  role: string;
  status: string;
}
