import { Component } from '@angular/core';

@Component({
  selector: 'app-file-operation',
  standalone: true,
  imports: [],
  templateUrl: './file-operation.component.html',
  styleUrl: './file-operation.component.scss'
})
export class FileOperationComponent {

}
