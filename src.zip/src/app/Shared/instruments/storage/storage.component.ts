import { Component } from '@angular/core';

@Component({
  selector: 'app-storage',
  standalone: true,
  imports: [],
  templateUrl: './storage.component.html',
  styleUrl: './storage.component.scss'
})
export class StorageComponent {

}
