import { Component } from '@angular/core';

@Component({
  selector: 'app-telemetrics',
  standalone: true,
  imports: [],
  templateUrl: './telemetrics.component.html',
  styleUrl: './telemetrics.component.scss'
})
export class TelemetricsComponent {

}
