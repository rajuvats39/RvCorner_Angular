export interface MessegeResponse {
    isSuccess: boolean;
    messege: string;
}