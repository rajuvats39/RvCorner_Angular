export const environment = {
  production: true,
  apiUrl: 'http://localhost:4200',
  baseApiUrl:'https://localhost:7241'
};
