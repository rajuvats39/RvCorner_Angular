export const environment = {
  production: false,
  apiUrl: 'http://localhost:4200',
  baseApiUrl:'https://localhost:7241'
};

