import { Component } from '@angular/core';

@Component({
    selector: 'app-selector-as-tag',
    templateUrl: './selector-as-tag.component.html',
    styleUrls: ['./selector-as-tag.component.scss'],
    standalone: false
})
export class SelectorAsTagComponent {

}
