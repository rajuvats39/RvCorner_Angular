import { Component } from '@angular/core';

@Component({
    selector: 'app-style-property',
    templateUrl: './style-property.component.html',
    styles: ["h2{font-weight: 800;color:red}"],
    standalone: false
})
export class StylePropertyComponent {

}
