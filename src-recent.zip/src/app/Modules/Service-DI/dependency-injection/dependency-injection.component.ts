import { Component } from '@angular/core';

@Component({
    selector: 'app-dependency-injection',
    templateUrl: './dependency-injection.component.html',
    styleUrl: './dependency-injection.component.scss',
    standalone: false
})
export class DependencyInjectionComponent {

}
