import { Component } from '@angular/core';

@Component({
    selector: 'app-service-di',
    templateUrl: './service-di.component.html',
    styleUrl: './service-di.component.scss',
    standalone: false
})
export class ServiceDIComponent {

}
