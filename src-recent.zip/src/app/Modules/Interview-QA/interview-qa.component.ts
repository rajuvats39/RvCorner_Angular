import { Component } from '@angular/core';

@Component({
    selector: 'app-interview-qa',
    templateUrl: './interview-qa.component.html',
    styleUrl: './interview-qa.component.scss',
    standalone: false
})
export class InterviewQAComponent {

}
