import { Component } from '@angular/core';

@Component({
    selector: 'app-http',
    templateUrl: './http.component.html',
    styleUrl: './http.component.scss',
    standalone: false
})
export class HTTPComponent {

}
