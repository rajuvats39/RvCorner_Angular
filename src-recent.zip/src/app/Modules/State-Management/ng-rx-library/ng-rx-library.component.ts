import { Component } from '@angular/core';

@Component({
    selector: 'app-ng-rx-library',
    templateUrl: './ng-rx-library.component.html',
    styleUrl: './ng-rx-library.component.scss',
    standalone: false
})
export class NgRxLibraryComponent {

}
