import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { GetDataComponent } from './getdata/getdata.component';
import { ToasterComponent } from './toaster/toaster.component';
import { MydevelopmentsComponent } from './mydevelopments.component';
import { StudentsCrudComponent } from './students-crud/students-crud.component';
import { EmployeesManagementComponent } from './employees-management/employees-management.component';
import { EmployeesDepartmentsListComponent } from './employees-management/employees-departments-list/employees-departments-list';

const routes: Routes = [
  { path: '', component: MydevelopmentsComponent },
  { path: 'toastrDemo', component: ToasterComponent },
  { path: 'getData', component: GetDataComponent },
  { path: 'students-crud', component: StudentsCrudComponent },
  { path: 'employeesManagement', component: EmployeesManagementComponent },
  { path: 'employeeDepartmentList', component: EmployeesDepartmentsListComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MydevelopmentsRoutingModule {}
