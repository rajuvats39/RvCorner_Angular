import { Component, OnInit } from '@angular/core';
import { EmployeesManagementService } from './employees-management.service';
import { NgForm } from '@angular/forms';
import { AppNotificationService } from '../../../Shared/notifications/app-notification.service';
import { Router } from '@angular/router';
import { MydevelopmentSharedService } from '../mydevelopment-shared.service';
import { CommonUtilityService } from '../../../Shared/common-utility.service';

@Component({
  selector: 'app-employees-management',
  standalone: false,
  templateUrl: './employees-management.component.html',
  styleUrl: './employees-management.component.scss',
})
export class EmployeesManagementComponent implements OnInit {
  public departmentList: any[] = [];
  public firstName: string;
  public lastName: string;
  public email: string;
  public phoneNumber: string;
  public dateOfBirth: string;
  public joiningDate: string;
  public departmentId: number;
  public departmentName: string;
  public gender: string;
  public skills: string[] = [];
  public resumePath: File | string;
  public profileImage: File | string;
  public isActive: boolean;
  public salary: number;
  public experienceYears: number;
  public passwordHash: string;
  public bio: string;
  public skillsList = [{ skillName: 'C#' }, { skillName: 'SQL' }, { skillName: '.NET Core' }, { skillName: 'Angular' }, { skillName: 'React' }, { skillName: 'JavaScript' }];
  public employeesData: any;
  public isEditMode: boolean = false;

  constructor(
    private readonly router: Router,
    private readonly commonUtilityService: CommonUtilityService,
    private readonly appNotificationService: AppNotificationService,
    private readonly mydevelopmentSharedService: MydevelopmentSharedService,
    private readonly employeesManagementService: EmployeesManagementService
  ) { }

  ngOnInit(): void {
    if (!this.employeesData) {
      this.getAllDepartments();
    }
    this.employeesData = this.mydevelopmentSharedService.getMyDevDetails();
    if (this.employeesData) {
      this.isEditMode = true;
      this.firstName = this.employeesData.firstName;
      this.lastName = this.employeesData.lastName;
      this.email = this.employeesData.email;
      this.phoneNumber = this.employeesData.phoneNumber;
      this.dateOfBirth = this.formatDateForInput(this.employeesData.dateOfBirth);
      this.joiningDate = this.formatDateForInput(this.employeesData.joiningDate);
      this.departmentId = this.employeesData.departmentId;
      this.gender = this.employeesData.gender;
      this.skills = this.employeesData.skills ? this.employeesData.skills.split(',') : [];
      this.resumePath = this.employeesData.resumePath;
      this.profileImage = this.employeesData.profileImage;
      this.isActive = this.employeesData.isActive;
      this.salary = this.employeesData.salary;
      this.experienceYears = this.employeesData.experienceYears;
      this.passwordHash = this.employeesData.passwordHash;
      this.bio = this.employeesData.bio;
    }
  }

  private formatDateForInput(dateString: string): string {
    return dateString ? dateString.split('T')[0] : '';
  }

  public getAllDepartments(): void {
    this.employeesManagementService.getAllDepartments().subscribe((response) => {
      if (response.isSuccess) {
        this.departmentList = response.data;
      } else {
        this.appNotificationService.error(response.message);
      }
    });
  }

  public onSkillChange(skill: string, event: Event): void {
    const isChecked = (event.target as HTMLInputElement).checked;
    this.skills = isChecked ? [...this.skills, skill].filter((s, i, arr) => arr.indexOf(s) === i) : this.skills.filter(s => s !== skill);
  }

  public onFileSelect(event: any, fileType: string): void {
    if (fileType === 'resume') {
      this.resumePath = event.target.files[0];
    } else if (fileType === 'image') {
      this.profileImage = event.target.files[0];
    }
  }

  public uploadPhoto(event: any) {
    // var file = event.target.files[0];
    // const formData: FormData = new FormData();
    // formData.append('file', file, file.name);
    // this.employeesManagementService.uploadPhoto(formData).subscribe((data: any) => {
    //   this.profileImage = data.toString();
    //   this.filePath = this.employeesManagementService.photoUrl + this.profileImage;
    // })
  }

  public addUpdateEmployee(form: NgForm): void {
    if (form && !form.valid) {
      this.appNotificationService.error('Please fill in all required fields.');
      return;
    }
    const request: any = {
      firstName: this.firstName,
      lastName: this.lastName,
      email: this.email,
      phoneNumber: this.phoneNumber,
      dateOfBirth: this.dateOfBirth,
      joiningDate: this.joiningDate,
      departmentId: this.departmentId,
      gender: this.gender,
      skills: this.skills.toString(),
      resumePath: this.resumePath ? this.resumePath.toString() : "/fakePath",
      profileImage: this.profileImage ? this.profileImage.toString() : "/fakePath",
      isActive: this.isActive,
      salary: this.salary,
      experienceYears: this.experienceYears,
      passwordHash: this.passwordHash,
      bio: this.bio,
    };
    if (this.isEditMode) {
      request.employeeId = this.employeesData.employeeId;
      this.employeesManagementService.updateEmployee(request).subscribe((response) => {
        if (response.isSuccess) {
          this.appNotificationService.success(response.message);
          form.resetForm();
          this.viewEmployeeList();
        } else {
          this.appNotificationService.error(response.message);
        }
      });
    } else {
      this.employeesManagementService.addEmployee(request).subscribe((response) => {
          if (response.isSuccess) {
            this.appNotificationService.success(response.message);
            form.resetForm();
            // this.uploadFiles();
            this.viewEmployeeList();
          } else {
            this.appNotificationService.error(response.message);
          }
        });
    }
  }

  public resetForm(form: NgForm): void {
    form.resetForm();
    this.skills = [];
  }

  public viewEmployeeList(): void {
    this.router.navigate(['/myDevelopment/employeeDepartmentList']);
  }

}
