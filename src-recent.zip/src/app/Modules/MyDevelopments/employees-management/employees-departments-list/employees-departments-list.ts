import { Component, OnInit } from '@angular/core';
import { AppNotificationService } from '../../../../Shared/notifications/app-notification.service';
import { EmployeesManagementService } from '../employees-management.service';
import { Router } from '@angular/router';
import { MydevelopmentSharedService } from '../../mydevelopment-shared.service';

@Component({
  selector: 'app-employees-departments-list',
  standalone: false,
  templateUrl: './employees-departments-list.component.html',
  styleUrls: ['./employees-departments-list.component.scss']
})
export class EmployeesDepartmentsListComponent implements OnInit {

  public gridList: any[] = [];

  constructor(
    private readonly router: Router,
    private readonly appNotificationService: AppNotificationService,
    private readonly employeesManagementService: EmployeesManagementService,
    private readonly mydevelopmentSharedService: MydevelopmentSharedService
  ) { }

  ngOnInit(): void {
    this.getAllEmployees();
  }

  public getAllEmployees(): void {
    this.employeesManagementService.getAllEmployees().subscribe((response) => {
      if (response.isSuccess) {
        this.gridList = response.data;
      } else {
        this.appNotificationService.error(response.message);
      }
    });
  }

  public updateEmployee(dataItem): void {
    this.mydevelopmentSharedService.setMyDevDetails({
      employeeId: dataItem.employeeId,
      firstName: dataItem.firstName,
      lastName: dataItem.lastName,
      email: dataItem.email,
      phoneNumber: dataItem.phoneNumber,
      dateOfBirth: dataItem.dateOfBirth,
      joiningDate: dataItem.joiningDate,
      departmentId: dataItem.departmentId,
      departmentName: dataItem.departmentName,
      gender: dataItem.gender,
      skills: dataItem.skills,
      resumePath: dataItem.resumePath,
      profileImage: dataItem.profileImage,
      isActive: dataItem.isActive,
      salary: dataItem.salary,
      experienceYears: dataItem.experienceYears,
      passwordHash: dataItem.passwordHash,
      bio: dataItem.bio,
    });
    this.router.navigate(['/myDevelopment/employeesManagement']);
  }

  public deleteEmployee(dataItem): void {
    const request: any = {
      employeeId: dataItem.employeeId
    };
    this.employeesManagementService.deleteEmployee(request).subscribe((response) => {
      if (response.isSuccess) {
        this.appNotificationService.success(response.message);
        this.getAllEmployees();
      } else {
        this.appNotificationService.error(response.message);
      }
    })
  }

  public viewAddEmployee(): void {
    this.router.navigate(['/myDevelopment/employeesManagement']);
  }

  public viewAddDepartment(): void {
    this.router.navigate(['/myDevelopment/departmentManagement']);
  }

}
