export class GetdataResponse {
    id?: number;
    name?: string;
    email?: string;
    phone?: string;
    username?: string;
    website?: string;
    companyName?: string;
    address?: string;
    city?: string;
    zipCode?: string;
}