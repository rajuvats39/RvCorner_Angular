import { Component } from '@angular/core';

@Component({
    selector: 'app-storage',
    imports: [],
    templateUrl: './storage.component.html',
    styleUrl: './storage.component.scss'
})
export class StorageComponent {

}
